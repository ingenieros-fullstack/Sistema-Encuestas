// src/seeders/seedAdminYUsuario.js
import bcrypt from "bcryptjs";
import Usuario from "../models/Usuario.js";
import Empresa from "../models/Empresa.js";
import DataEmpleado from "../models/DataEmpleado.js";

export const seedAdminYUsuario = async () => {
  try {
    console.log("🚀 Iniciando creación de usuarios base...");

    // ================================
    // 🏢 1️⃣ Crear o recuperar empresa demo
    // ================================
    let empresa = await Empresa.findOne({ where: { nombre: "Empresa Demo" } });
    if (!empresa) {
      empresa = await Empresa.create({
        nombre: "Empresa Demo",
        direccion: "Dirección Demo",
        contacto: "Contacto Demo",
        telefono: "123456789",
        correo_electronico: "empresa@demo.com",
      });
      console.log("🏢 Empresa demo creada automáticamente.");
    } else {
      console.log("🏢 Empresa demo existente detectada.");
    }

    // ================================
    // ⚙️ Helper para crear empleado + usuario
    // ================================
    const crearEmpleadoYUsuario = async (numEmpleado, nombre, correo, rol, passPlano) => {
      correo = correo.trim().toLowerCase();

      // 1️⃣ Buscar o crear empleado (correo único)
      let empleado = await DataEmpleado.findOne({ where: { correo_electronico: correo } });

      if (!empleado) {
        empleado = await DataEmpleado.create({
          id_empresa: empresa.id_empresa,
          nombre,
          correo_electronico: correo,
          sexo: "O",
          fecha_ingreso: new Date(),
        });
        console.log(`👤 Empleado creado: ${nombre}`);
      } else {
        console.log(`👤 Empleado ya existe: ${nombre}`);
      }

      // 2️⃣ Crear o actualizar usuario vinculado a ese empleado
      const hashedPass = await bcrypt.hash(passPlano, 10);

      let usuario = await Usuario.findOne({
        where: { numero_empleado: numEmpleado },
      });

      if (usuario) {
        usuario.password = hashedPass;
        usuario.rol = rol;
        usuario.estatus = 1;
        usuario.must_change_password = false;
        await usuario.save();
        console.log(`✅ Usuario actualizado (${numEmpleado} / rol: ${rol})`);
      } else {
        await Usuario.create({
          id_data: empleado.id_data,
          numero_empleado: numEmpleado,
          correo_electronico: correo, // sigue existiendo en la tabla
          password: hashedPass,
          rol,
          estatus: 1,
          must_change_password: false,
        });
        console.log(`✅ Usuario creado (${numEmpleado} / rol: ${rol})`);
      }
    };

    // ================================
    // 👥 3️⃣ Crear usuarios base
    // ================================
    await crearEmpleadoYUsuario("EMP001", "Administrador", "admin@correo.com", "admin", "123456");
    await crearEmpleadoYUsuario("EMP002", "Empleado Demo", "empleado@correo.com", "empleado", "654321");
    await crearEmpleadoYUsuario("EMP003", "Supervisor Demo", "supervisor@correo.com", "supervisor", "789012");

    console.log("🎯 Usuarios base verificados y actualizados correctamente.");
  } catch (error) {
    console.error("❌ Error creando usuarios base:", error);
  }
};
